# Intelligent Traffic Surveillance

This project monitors traffic patterns in real-time, detects suspicious activities, and optimizes traffic flow. Built with a MERN stack, it ensures enhanced safety and quick response to emergencies.
